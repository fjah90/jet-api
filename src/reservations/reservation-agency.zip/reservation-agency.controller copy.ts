import { Body, Controller, Post, UseInterceptors, UsePipes, ValidationPipe } from '@nestjs/common';
import { ApiCreatedResponse, ApiInternalServerErrorResponse, ApiOperation, ApiTags } from '@nestjs/swagger';
import { SentryInterceptor } from 'src/interceptors/sentry.interceptor';
import { StatsdService } from 'src/statsd/statsd.service';
import { HttPStatusResponse } from 'src/pnr/responsesDto/http-status.dto';
import { GetReservationsResponseDto } from './responsesDto/get-reservations.dto';
import { RetrieveReservationsAgencyDto } from './dto/get-reservations-agency.dto';
import { ReservationAgencyServiceCopy } from './reservation-agency.service copy';

@UseInterceptors(SentryInterceptor)
@ApiTags('Reservation_Agency')
@Controller('reservation-agency')
export class ReservationAgencyControllerCopy {
  constructor(
    private readonly reservationService: ReservationAgencyServiceCopy,
    private statsdService: StatsdService
  ) {}

  @UsePipes(new ValidationPipe({ transform: true }))
  @ApiOperation({
    summary: 'Retrieves reservations',
    description: 'This endpoint retrieves reservations from the system.',
  })
  @ApiCreatedResponse({
    description: 'Reservations were successfully met.',
    type: [GetReservationsResponseDto],
  })
  @ApiInternalServerErrorResponse({
    description: 'Reservation list Error.',
    type: HttPStatusResponse,
  })
  @Post('/list')
  async getReservations(
    @Body(ValidationPipe) retrieveReservationsDto: RetrieveReservationsAgencyDto
  ): Promise<GetReservationsResponseDto[]> {
    const start = Date.now();
    const response = await this.reservationService.retrieveReservations(
      retrieveReservationsDto,
      retrieveReservationsDto.token
    );
    const end = Date.now();
    await this.statsdService.timing('_reservations_getReservations_post_response_time', end - start);
    return response;
  }
}
