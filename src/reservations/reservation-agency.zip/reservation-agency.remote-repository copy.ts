import { Parser } from '../utils/json-xml.parser';
import { JsonLogger } from 'src/utils/json-logger';
import { axiosInstance } from 'src/interceptors/axios.interceptor';

export class ReservationAgencyRemoteRepositoryCopy {
  private logger = new JsonLogger(ReservationAgencyRemoteRepositoryCopy.name);
  private async axiosClient(args, url, headers, actionType, user) {
    // if (JSON.parse(process.env.SHOW_SWAGGER))
    this.logger.log(`user:${user} [LOG INFO BEFORE ${actionType}] ` + args);
    const xmlResponse = await axiosInstance.post(url, args, headers);
    const jsonResponse: any = await Parser.convertXMLToJSON(xmlResponse);
    // if (JSON.parse(process.env.SHOW_SWAGGER))
    this.logger.log(`user:${user} [LOG INFO AFTER ${actionType}] ${JSON.stringify(jsonResponse)} `);
    return jsonResponse;
  }
  public async retrievePnr({ token, confirmationNumber }, user: string) {
    const url = `${process.env.RADIXX_URL}/Radixx.ConnectPoint/ConnectPoint.Reservation.svc`;
    const payload = {
      'tem:RetrievePNR': {
        'tem:RetrievePnrRequest': {
          'rad:SecurityGUID': token,
          'rad:CarrierCodes': {
            'rad:CarrierCode': {
              'rad:AccessibleCarrierCode': '?',
            },
          },
          'rad1:ActionType': 'GetReservation',
          'rad1:ReservationInfo': {
            'rad:SeriesNumber': 299,
            'rad:ConfirmationNumber': confirmationNumber,
          },
        },
      },
    };

    const headers = {
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        SOAPAction: 'http://tempuri.org/IConnectPoint_Reservation/RetrievePNR',
      },
    };
    try {
                    //convertJSONToSoapRequest(payload, 'Reservation');
      const args = ReservationAgencyRemoteRepositoryCopy.convertJSONToSoapRequest(payload, 'Reservation');
      const jsonResponse: any = await this.axiosClient(args, url, headers, 'RETRIEVE PNR', user);
      return jsonResponse;
    } catch (error) {
      this.logger.error('Failed retrieve: ' + JSON.stringify(error.message));
    }
  }
  static convertJSONToSoapRequest(jsonArguments, rad1Schema, rad1SchemaSecondProperty = '') {
    const soapBody = Parser.parseJSONBodyToXML(jsonArguments);

    return `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/" xmlns:rad="http://schemas.datacontract.org/2004/07/Radixx.ConnectPoint.Request"  xmlns:arr="http://schemas.microsoft.com/2003/10/Serialization/Arrays" xmlns:rad1="http://schemas.datacontract.org/2004/07/Radixx.ConnectPoint.${rad1Schema}.Request${
      rad1SchemaSecondProperty ? `.${rad1SchemaSecondProperty}` : ''
    }">
          <soapenv:Header/>
          <soapenv:Body>
            ${soapBody}
          </soapenv:Body>
        </soapenv:Envelope>`;
  }
}
